




@REM ������7
sc stop SharedAccess
sc config SharedAccess start= disabled


NETSH WLAN stop 
net stop SharedAccess
net stop WLAN
net stop pla
net stop winmgmt



@REM �Ŀ��� ����
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ics_off.ps1"


@REM ������7
sc stop SharedAccess
sc config SharedAccess start= disabled


NETSH WLAN stop 
net stop SharedAccess
net stop WLAN
net stop pla
net stop winmgmt


pause

