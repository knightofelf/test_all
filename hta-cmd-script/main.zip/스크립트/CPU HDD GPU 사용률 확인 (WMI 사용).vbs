Set objWMI = GetObject("winmgmts:\\.\root\cimv2")
Set colItems = objWMI.ExecQuery("SELECT * FROM Win32_Processor")

For Each objItem In colItems
    WScript.Echo "CPU ����: " & objItem.LoadPercentage & "%"
Next

Set shell = CreateObject("WScript.Shell")
' shell.Run "powershell.exe -Command Get-Counter '\PhysicalDisk(_Total)\% Disk Time'", 1, True
' shell.Run "powershell.exe -Command Get-Counter '\PhysicalDisk(0 C:)\% Disk Time'", 1, True

shell.Run "powershell.exe -Command Get-Counter '\PhysicalDisk(_Total)\% Disk Time'; Pause", 1, True
' shell.Run "powershell.exe -Command Get-Counter '\PhysicalDisk(_Total)\% Disk Time' | Out-File C:\disk_usage.txt", 1, True
'  shell.Run "powershell.exe -NoExit -Command Get-Counter '\PhysicalDisk(_Total)\% Disk Time'", 1, True


shell.Run "cmd.exe /k powershell.exe -Command ""Get-WmiObject Win32_VideoController | Select-Object Name, AdapterRAM"" & pause", 1, True

shell.Run "cmd.exe /k powershell.exe -Command ""nvidia-smi --query-gpu=utilization.gpu --format=csv"" & pause", 1, True

shell.Run "powershell.exe -Command ""Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force"'; Pause"", 1, True

shell.Run "cmd.exe /k powershell.exe -File .\gpu_util.ps1 & pause", 1, True

shell.Run "cmd.exe /k powershell.exe -Command ""Get-Counter -ListSet * | Where-Object { $_.CounterSetName -like '*GPU*' }"" & pause", 1, True


WScript.Quit







' Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
' Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force

' | ��å �̸�       | ���� |
' | Restricted     | �⺻��. ��ũ��Ʈ ���� �Ұ� |
' | RemoteSigned   | ���� ��ũ��Ʈ�� ���� ����. ���ͳݿ��� ���� �� ���� �ʿ� |
' | Unrestricted   | ��� ��ũ��Ʈ ���� ����. ���� ���� ���� |



shell.Run "powershell.exe -Command ""Get-WmiObject Win32_VideoController | Select-Object Name, AdapterRAM"'; Pause"", 1, True

shell.Run "cmd.exe /k powershell.exe -Command ""nvidia-smi --query-gpu=utilization.gpu --format=csv"" & pause", 1, True

shell.Run "'.\gpu_util.ps1 -FormatTable'; Pause", 1, True

shell.Run "powershell.exe -Command Get-Counter '-ListSet * | Where-Object { $_.CounterSetName -like "*GPU*" }; Pause'", 1, True



WScript.Sleep 3000 ' 3�� ���� �Ͻ� ����
WScript.Echo "��� �� �Է��� �޽��ϴ�..."
WScript.Sleep 2000
userInput = InputBox("�̸��� �Է��ϼ���:")




Set objWMI = GetObject("winmgmts:\\.\root\cimv2")
Set colDisks = objWMI.ExecQuery("SELECT * FROM Win32_LogicalDisk WHERE DriveType = 3")

For Each disk In colDisks
    total = disk.Size / 1024 / 1024 / 1024
    free = disk.FreeSpace / 1024 / 1024 / 1024
    used = total - free
    percentUsed = (used / total) * 100

    WScript.Echo "����̺� " & disk.DeviceID
    WScript.Echo "��ü �뷮: " & Round(total, 2) & " GB"
    WScript.Echo "��� ��: " & Round(used, 2) & " GB (" & Round(percentUsed, 1) & "%)"
    WScript.Echo "���� ����: " & Round(free, 2) & " GB"
    WScript.Echo "-----------------------------"
Next



