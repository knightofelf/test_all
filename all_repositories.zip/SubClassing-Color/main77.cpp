#include <windows.h>
#include <math.h>
#include <commctrl.h>
#include <algorithm>

#pragma comment(lib, "comctl32.lib")


using namespace std;

// --- 1. Colorz �ٽ� ���� �˰����� (RGB �� HSL ��ȯ) ---
struct HSL {
    double h; // Hue (0.0 ~ 360.0)
    double s; // Saturation (0.0 ~ 1.0)
    double l; // Lightness (0.0 ~ 1.0)
};

// RGB���� HSL ��ȯ ����
HSL RGBtoHSL(COLORREF rgb) {
    double r = GetRValue(rgb) / 255.0;
    double g = GetGValue(rgb) / 255.0;
    double b = GetBValue(rgb) / 255.0;

    double maxVal = max(r, std::max(g, b));
    double minVal = min(r, std::min(g, b));
    
    HSL hsl = { 0.0, 0.0, (maxVal + minVal) / 2.0 };

    if (maxVal != minVal) {
        double d = maxVal - minVal;
        hsl.s = hsl.l > 0.5 ? d / (2.0 - maxVal - minVal) : d / (maxVal + minVal);

        if (maxVal == r)      hsl.h = (g - b) / d + (g < b ? 6.0 : 0.0);
        else if (maxVal == g) hsl.h = (b - r) / d + 2.0;
        else if (maxVal == b) hsl.h = (r - g) / d + 4.0;
        
        hsl.h *= 60.0;
    }
    return hsl;
}

// HSL Helper �Լ�
double HueToRGB(double v1, double v2, double vH) {
    if (vH < 0.0) vH += 1.0;
    if (vH > 1.0) vH -= 1.0;
    if ((6.0 * vH) < 1.0) return (v1 + (v2 - v1) * 6.0 * vH);
    if ((2.0 * vH) < 1.0) return (v2);
    if ((3.0 * vH) < 2.0) return (v1 + (v2 - v1) * ((2.0 / 3.0) - vH) * 6.0);
    return (v1);
}

// HSL���� RGB ��ȯ ����
COLORREF HSLtoRGB(HSL hsl) {
    double r, g, b;

    if (hsl.s == 0) {
        r = g = b = hsl.l; // ��ä�� (�׷��̽�����)
    } else {
        double v2 = hsl.l < 0.5 ? hsl.l * (1.0 + hsl.s) : (hsl.l + hsl.s) - (hsl.l * hsl.s);
        double v1 = 2.0 * hsl.l - v2;

        r = HueToRGB(v1, v2, (hsl.h / 360.0) + (1.0 / 3.0));
        g = HueToRGB(v1, v2, (hsl.h / 360.0));
        b = HueToRGB(v1, v2, (hsl.h / 360.0) - (1.0 / 3.0));
    }

    return RGB((BYTE)(r * 255), (BYTE)(g * 255), (BYTE)(b * 255));
}

// --- 2. WinAPI UI ������ ���� �� �׷��� ������ ---
COLORREF g_SelectedColor = RGB(255, 0, 0); // �⺻ ���� ����
HBRUSH g_hColorBrush = NULL;               // ���� �̸����� �귯��

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static HWND hSliderH, hSliderS, hSliderL;
    static HWND hStaticPreview;

    switch (msg) {
    case WM_CREATE: {
        InitCommonControls();
        g_hColorBrush = CreateSolidBrush(g_SelectedColor);

        // HSL �� Ȯ��
        HSL currentHsl = RGBtoHSL(g_SelectedColor);

        // UI �����̴� ���� (Hue, Saturation, Lightness ���� ����)
        CreateWindowW(L"STATIC", L"Hue:", WS_CHILD | WS_VISIBLE, 20, 20, 80, 20, hwnd, NULL, NULL, NULL);
        hSliderH = CreateWindowW(TRACKBAR_CLASSW, L"", WS_CHILD | WS_VISIBLE | TBS_AUTOTICKS, 100, 20, 200, 30, hwnd, (HMENU)101, NULL, NULL);
        SendMessage(hSliderH, TBM_SETRANGE, TRUE, MAKELPARAM(0, 360));
        SendMessage(hSliderH, TBM_SETPOS, TRUE, (LPARAM)currentHsl.h);

        CreateWindowW(L"STATIC", L"Saturation:", WS_CHILD | WS_VISIBLE, 20, 60, 80, 20, hwnd, NULL, NULL, NULL);
        hSliderS = CreateWindowW(TRACKBAR_CLASSW, L"", WS_CHILD | WS_VISIBLE | TBS_AUTOTICKS, 100, 60, 200, 30, hwnd, (HMENU)102, NULL, NULL);
        SendMessage(hSliderS, TBM_SETRANGE, TRUE, MAKELPARAM(0, 100));
        SendMessage(hSliderS, TBM_SETPOS, TRUE, (LPARAM)(currentHsl.s * 100));

        CreateWindowW(L"STATIC", L"Lightness:", WS_CHILD | WS_VISIBLE, 20, 100, 80, 20, hwnd, NULL, NULL, NULL);
        hSliderL = CreateWindowW(TRACKBAR_CLASSW, L"", WS_CHILD | WS_VISIBLE | TBS_AUTOTICKS, 100, 100, 200, 30, hwnd, (HMENU)103, NULL, NULL);
        SendMessage(hSliderL, TBM_SETRANGE, TRUE, MAKELPARAM(0, 100));
        SendMessage(hSliderL, TBM_SETPOS, TRUE, (LPARAM)(currentHsl.l * 100));

        // ���� �ǽð� �̸����� Static ���� ����
        hStaticPreview = CreateWindowW(L"STATIC", L"", WS_CHILD | WS_VISIBLE | SS_OWNERDRAW, 320, 20, 120, 110, hwnd, (HMENU)201, NULL, NULL);
        break;
    }

    case WM_HSCROLL: { // �����̴� �� ���� �� �ǽð� �޽��� ����ä��
        HSL targetHsl;
        targetHsl.h = SendMessage(hSliderH, TBM_GETPOS, 0, 0);
        targetHsl.s = SendMessage(hSliderS, TBM_GETPOS, 0, 0) / 100.0;
        targetHsl.l = SendMessage(hSliderL, TBM_GETPOS, 0, 0) / 100.0;

        // �˰������� ���� �ǽð� ��ȯ �� ���� ���� �� ������Ʈ
        g_SelectedColor = HSLtoRGB(targetHsl);

        // ���� GDI �귯�� ��� �� ���� ä��
        if (g_hColorBrush) DeleteObject(g_hColorBrush);
        g_hColorBrush = CreateSolidBrush(g_SelectedColor);

        // �̸����� ȭ�� ���� ����
        InvalidateRect(hStaticPreview, NULL, TRUE);
        break;
    }

    case WM_DRAWITEM: { // SS_OWNERDRAW ������ �̸����� �ڽ� �׸��� [1.21]
        LPDRAWITEMSTRUCT lpDIS = (LPDRAWITEMSTRUCT)lParam;
        if (lpDIS->CtlID == 201) {
            FillRect(lpDIS->hDC, &lpDIS->rcItem, g_hColorBrush); // �ǽð� ��ȯ�� �������� �ڽ��� ä��
        }
        break;
    }

    case WM_DESTROY:
        if (g_hColorBrush) DeleteObject(g_hColorBrush);
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// --- 3. WinMain ������ ---
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASSEXW wc = { sizeof(WNDCLASSEXW), CS_HREDRAW | CS_VREDRAW, WndProc, 0, 0, hInstance, NULL, NULL, NULL, NULL, L"ColorzClass", NULL };
    RegisterClassExW(&wc);

    HWND hwnd = CreateWindowExW(0, L"ColorzClass", L"CodeProject Colorz WinAPI ����", WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME, CW_USEDEFAULT, CW_USEDEFAULT, 480, 190, NULL, NULL, hInstance, NULL);
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}

